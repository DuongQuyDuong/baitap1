# Phân tích EXPLAIN trước và sau tối ưu

Thử nghiệm sử dụng **10.000 giao dịch giả lập**, không phải 5 triệu giao dịch trong tình huống của đề. Khi chạy lại hai truy vấn sau khi đã tạo Index `idx_type_date`, kết quả EXPLAIN ghi nhận:

| Chỉ số | Truy vấn cũ (YEAR/MONTH) | Truy vấn tối ưu (khoảng ngày) |
|---|---:|---:|
| type | `ref` | `range` |
| possible_keys | `idx_type_date` | `idx_type_date` |
| key | `idx_type_date` | `idx_type_date` |
| key_len | 83 | 89 |
| rows (ước tính) | 3.334 | 130 |

Truy vấn cũ bọc hàm `YEAR()` và `MONTH()` quanh `created_at`, nên không khai thác hiệu quả phần ngày tháng của Index thông thường. Dù vậy, truy vấn cũ vẫn dùng được phần đầu `transaction_type`, do Index đã tồn tại lúc đo. Truy vấn mới lọc bằng khoảng `>= 2026-06-01` và `< 2026-07-01`, giúp MySQL dùng Index kết hợp để thu hẹp vùng tìm kiếm.

Số dòng **ước tính** giảm từ 3.334 xuống 130. Đây là khác biệt trong kế hoạch thực thi, **không phải** bằng chứng thời gian chạy thực tế tăng tốc tương ứng.
