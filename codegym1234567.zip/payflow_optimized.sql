-- PAYFLOW: TOI UU BAO CAO NAP TIEN THANG 06/2026
-- MySQL 8.0+. Script co the chay lai: khong nhan doi du lieu mau/Index.
-- Du lieu 10.000 dong duoc tao de minh hoa; khong phai 5 trieu giao dich that.

CREATE DATABASE IF NOT EXISTS payflow_db;
USE payflow_db;

-- 1. Cau truc bang
CREATE TABLE IF NOT EXISTS Transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    amount DECIMAL(15,2),
    transaction_type VARCHAR(20),
    created_at DATETIME
);

-- 2. Chi tao 10.000 giao dich minh hoa NEU bang hien dang rong.
-- Bo qua phan nay neu su dung bang du lieu that.
SET SESSION cte_max_recursion_depth = 11000;
INSERT INTO Transactions (user_id, amount, transaction_type, created_at)
WITH RECURSIVE seq AS (
    SELECT 0 AS n
    UNION ALL
    SELECT n + 1 FROM seq WHERE n < 9999
)
SELECT
    (n % 100) + 1,
    (n % 1000) + 0.50,
    CASE
        WHEN n % 3 = 0 THEN 'DEPOSIT'
        WHEN n % 3 = 1 THEN 'WITHDRAW'
        ELSE 'TRANSFER'
    END,
    DATE_ADD('2025-01-01 00:00:00', INTERVAL (n % 730) DAY)
FROM seq
WHERE NOT EXISTS (SELECT 1 FROM Transactions LIMIT 1);

SELECT COUNT(*) AS total_transactions FROM Transactions;

-- 3. Truy van cu: YEAR/MONTH boc quanh cot thoi gian (Non-SARGable).
-- Neu Index da ton tai, MySQL van co the dung phan transaction_type cua Index.
EXPLAIN
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND YEAR(created_at) = 2026
  AND MONTH(created_at) = 6;

-- 4. Composite Index: transaction_type (so sanh bang) + created_at (khoang).
-- Chi tao Index neu chua co, tranh loi Duplicate key name khi chay lai.
SET @index_exists := (
    SELECT COUNT(*)
    FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'Transactions'
      AND index_name = 'idx_type_date'
);
SET @index_sql := IF(
    @index_exists = 0,
    'CREATE INDEX idx_type_date ON Transactions(transaction_type, created_at)',
    'SELECT ''Index idx_type_date da ton tai'' AS note'
);
PREPARE index_stmt FROM @index_sql;
EXECUTE index_stmt;
DEALLOCATE PREPARE index_stmt;

-- 5. Truy van toi uu: nua khoang [01/06/2026, 01/07/2026)
EXPLAIN
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND created_at >= '2026-06-01 00:00:00'
  AND created_at < '2026-07-01 00:00:00';

-- 6. Kiem tra tong tien: hai truy van can cho ket qua giong nhau.
SELECT 'legacy' AS query_version, SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND YEAR(created_at) = 2026
  AND MONTH(created_at) = 6
UNION ALL
SELECT 'optimized', SUM(amount)
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND created_at >= '2026-06-01 00:00:00'
  AND created_at < '2026-07-01 00:00:00';
