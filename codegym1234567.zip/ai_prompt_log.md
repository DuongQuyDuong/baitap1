# Nhật ký trao đổi với AI – PayFlow

*Bản tóm tắt được biên tập từ quá trình được AI hướng dẫn trong cuộc trao đổi thực hành; không phải bản chép nguyên văn từng lượt tin nhắn.*

## 1. EXPLAIN cho truy vấn cũ cho biết điều gì?

**Chủ đề trao đổi:** Tìm hiểu các cột `type`, `possible_keys`, `key`, `rows` và lỗi truy vấn dùng `YEAR()`/`MONTH()`.

**Kiến thức AI giải thích:** `type = ALL` là quét toàn bảng; `ref` là truy cập bằng Index với điều kiện phù hợp; `range` là truy cập theo khoảng. `possible_keys` liệt kê Index có thể dùng, `key` là Index thực tế được chọn, còn `rows` là ước tính số dòng cần xét. Lúc bảng mới tạo, EXPLAIN cho truy vấn cũ hiện `ALL` và `possible_keys = NULL`, nhưng bảng chưa có dữ liệu nên không thể suy ra hiệu suất thật.

## 2. Vì sao cần Composite Index và điều kiện SARGable?

**Chủ đề trao đổi:** Cách dùng Index trên `(transaction_type, created_at)` và thay hàm ngày tháng bằng điều kiện khoảng.

**Kiến thức AI giải thích:** Đặt cột lọc bằng (`transaction_type = 'DEPOSIT'`) trước cột lọc khoảng (`created_at`) để hỗ trợ mẫu truy vấn này. Hàm `YEAR(created_at)`/`MONTH(created_at)` thường cản trở việc sử dụng phần ngày tháng của B-Tree Index thông thường. Viết khoảng nửa mở `created_at >= '2026-06-01' AND created_at < '2026-07-01'` để sử dụng Index hiệu quả và bao quát cả ngày 30/06.

## 3. Kết quả kiểm thử và giới hạn kết luận

**Chủ đề trao đổi:** Tạo 10.000 giao dịch mẫu, chạy EXPLAIN cũ/mới, đọc kết quả và chuẩn bị báo cáo.

**Kết quả đã quan sát trong MySQL Workbench:** Index `idx_type_date` được tạo thành công. Sau khi nạp 10.000 dòng, truy vấn cũ có `type = ref`, `key = idx_type_date`, `rows = 3334`; truy vấn tối ưu có `type = range`, `key = idx_type_date`, `rows = 130`. Vì so sánh này được thực hiện khi Index đã tồn tại ở cả hai truy vấn, kết quả không đo lường riêng tác động của việc tạo Index. `rows` là ước tính của Optimizer, không phải thời gian chạy.

## 4. Kiến thức bổ sung

**Chủ đề được gợi ý đào sâu:** Index Seek so với Index Scan; cấu trúc B-Tree; chi phí cập nhật Index khi bảng có nhiều `INSERT`/`UPDATE`/`DELETE`.

**Ghi chú:** Đây là nội dung để học tiếp, chưa ghi nhận là đã trực tiếp thử nghiệm trong bài này.
